# ProofPatch run evidence

Run: ff71c436-c446-4cdb-9085-a0b3fc8cb237
Status: Verified against this test suite

The regression fails on the frozen baseline, the identical mandatory suite passes on this repair, and the selected export matches the expected IDs.

Bundled synthetic fixture; verification is limited to this suite. Hashes identify bytes, not authorship or chronology. Human review is required.

The full suite always covers page sizes 2, 3 and 4. The preview uses the selected size.

## Re-run
Use Python 3.12. From snapshot/:
```
python -m pip install -r requirements.txt
PROOFPATCH_VARIANT=baseline python -m pytest tests/repro tests/acceptance
PROOFPATCH_VARIANT=candidate python -m pytest tests/repro tests/acceptance
```

A failing baseline and a rejected deliberate bad patch are expected.
IBM Bob session exports are separate provenance artifacts under evidence/bob in the project release.