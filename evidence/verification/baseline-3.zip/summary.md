# ProofPatch run evidence

Run: cc41ba5d-f05c-45ea-baab-e2fb113b774d
Status: Defect reproduced

The unchanged regression assertion fails on the baseline. The preview below uses your selected page size; the complete suite always tests 2, 3 and 4.

Bundled synthetic fixture; verification is limited to this suite. Hashes identify bytes, not authorship or chronology. Human review is required.

The full suite always covers page sizes 2, 3 and 4. The preview uses the selected size.

## Re-run
Use Python 3.12. From snapshot/:
```
python -m pip install -r requirements.txt
PROOFPATCH_VARIANT=baseline python -m pytest tests/repro tests/acceptance
PROOFPATCH_VARIANT=baseline python -m pytest tests/repro tests/acceptance
```

A failing baseline and a rejected deliberate bad patch are expected.
IBM Bob session exports are separate provenance artifacts under evidence/bob in the project release.