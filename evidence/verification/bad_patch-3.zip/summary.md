# ProofPatch run evidence

Run: 2de1435c-1550-46a2-94bb-674971e3be87
Status: Repair rejected

The repair fails required behavior checks. This deliberately incorrect negative control was correctly rejected.

Bundled synthetic fixture; verification is limited to this suite. Hashes identify bytes, not authorship or chronology. Human review is required.

The full suite always covers page sizes 2, 3 and 4. The preview uses the selected size.

## Re-run
Use Python 3.12. From snapshot/:
```
python -m pip install -r requirements.txt
PROOFPATCH_VARIANT=baseline python -m pytest tests/repro tests/acceptance
PROOFPATCH_VARIANT=bad_patch python -m pytest tests/repro tests/acceptance
```

A failing baseline and a rejected deliberate bad patch are expected.
IBM Bob session exports are separate provenance artifacts under evidence/bob in the project release.